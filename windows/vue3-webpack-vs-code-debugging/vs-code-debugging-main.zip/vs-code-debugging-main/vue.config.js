module.exports = {
	configureWebpack() {
		return {
			devtool: 'source-map'
		};
	}
};