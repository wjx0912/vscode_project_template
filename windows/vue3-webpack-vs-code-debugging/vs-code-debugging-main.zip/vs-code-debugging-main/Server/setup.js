const localValue = 'World!';

function setup(arg) {
	console.log(`${arg} ${localValue}`);
}

module.exports = {
	setup
}