const value = 'Clicked!';

export function method() {
	console.log(value);
}