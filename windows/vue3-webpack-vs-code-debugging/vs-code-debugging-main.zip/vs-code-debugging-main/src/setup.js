const value = 'Hello World!';

export function setup() {
	console.log(value);
}