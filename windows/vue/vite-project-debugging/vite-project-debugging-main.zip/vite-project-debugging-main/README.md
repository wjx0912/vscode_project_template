# How to debug a Vite app with VSCode

I don't know!

This is just a vanilla js project created using `create-vite`.
